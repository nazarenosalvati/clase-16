from setuptools import setup    

setup(
    name="mipaquete",
    version="1.1",
    description="Funciones para base de clientes",
    author="Nazareno Salvati",
    packages=["paquete"]
)